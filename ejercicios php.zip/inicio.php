<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
</head>
<body>
    <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
</head>

<body>
<?php

$password = 4;



//sintaxis de comparacion <=, <, >, >=, ==

if($password == 4){

    echo '<h3 style="color:green">Prueba superada</h3>';

}

else{

    echo '<h3 style="color:red">Prueba suspendida</h3>';

}

?>
</body>

</html>

</body>
</html>
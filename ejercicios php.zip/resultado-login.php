<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>resultado-login</title>
</head>
<body>
    <?php
    
    $rol = 'admin';
    
    
    
    //sintaxis de comparacion <=, <, >, >=, ==
    
    if($rol == 'admin'){
    
        echo '<a href="data.php">modificar datos';
    
    }
    
    else{
    
        echo '<a href="data.php">visualizar datos';
    
    }
    
    ?>
    </body>
</html>